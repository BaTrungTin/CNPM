﻿using System;
using System.Collections.Generic;

namespace qlyvanchuyencakoi.DAL.Models;

public partial class Shipper
{
    public int IdShipper { get; set; }

    public string NameS { get; set; } = null!;

    public string NumberPhone { get; set; } = null!;

    public string BienXo { get; set; } = null!;
}
