﻿using System;
using System.Collections.Generic;

namespace qlyvanchuyencakoi.DAL.Models;

public partial class FeedBack
{
    public int IdFeedBack { get; set; }

    public string IdProduct1 { get; set; } = null!;

    public string FeedBackContent { get; set; } = null!;
}
