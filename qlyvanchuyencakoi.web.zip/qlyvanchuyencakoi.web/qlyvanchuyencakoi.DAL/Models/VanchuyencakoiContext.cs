﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Pomelo.EntityFrameworkCore.MySql.Scaffolding.Internal;

namespace qlyvanchuyencakoi.DAL.Models;

public partial class VanchuyencakoiContext : DbContext
{
    public VanchuyencakoiContext()
    {
    }

    public VanchuyencakoiContext(DbContextOptions<VanchuyencakoiContext> options)
        : base(options)
    {
    }

    public virtual DbSet<FeedBack> FeedBacks { get; set; }

    public virtual DbSet<InfoProduct> InfoProducts { get; set; }

    public virtual DbSet<Product> Products { get; set; }

    public virtual DbSet<Shipper> Shippers { get; set; }

    public virtual DbSet<User> Users { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseMySql("server=localhost;database=vanchuyencakoi;user=root;password=ABC123abc", Microsoft.EntityFrameworkCore.ServerVersion.Parse("9.1.0-mysql"));

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder
            .UseCollation("utf8mb4_0900_ai_ci")
            .HasCharSet("utf8mb4");

        modelBuilder.Entity<FeedBack>(entity =>
        {
            entity.HasKey(e => e.IdFeedBack).HasName("PRIMARY");

            entity.ToTable("feed_back");

            entity.Property(e => e.IdFeedBack).HasColumnName("id_feed_back");
            entity.Property(e => e.FeedBackContent)
                .HasMaxLength(45)
                .HasDefaultValueSql("'***'")
                .HasColumnName("feed_back_content");
            entity.Property(e => e.IdProduct1)
                .HasMaxLength(45)
                .HasColumnName("id_product_1");
        });

        modelBuilder.Entity<InfoProduct>(entity =>
        {
            entity.HasKey(e => new { e.IdInfoProduct, e.ProducId, e.IdUser1 })
                .HasName("PRIMARY")
                .HasAnnotation("MySql:IndexPrefixLength", new[] { 0, 0, 0 });

            entity.ToTable("info_product");

            entity.Property(e => e.IdInfoProduct)
                .ValueGeneratedOnAdd()
                .HasColumnName("id_info_product");
            entity.Property(e => e.ProducId).HasColumnName("produc_id");
            entity.Property(e => e.IdUser1).HasColumnName("id_user_1");
            entity.Property(e => e.AllPrice)
                .HasMaxLength(45)
                .HasColumnName("all_price");
            entity.Property(e => e.PaymentMethod)
                .HasMaxLength(45)
                .HasDefaultValueSql("'COD'")
                .HasColumnName("payment_method");
            entity.Property(e => e.ShippingMethod)
                .HasMaxLength(45)
                .HasDefaultValueSql("'GHTk'")
                .HasColumnName("shipping_method");
            entity.Property(e => e.StatusShipping)
                .HasMaxLength(45)
                .HasColumnName("status_shipping");
        });

        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasKey(e => e.IdProduct).HasName("PRIMARY");

            entity
                .ToTable("product")
                .HasCharSet("utf8mb3")
                .UseCollation("utf8mb3_bin");

            entity.Property(e => e.IdProduct).HasColumnName("id_product");
            entity.Property(e => e.Image)
                .HasMaxLength(45)
                .HasColumnName("image");
            entity.Property(e => e.Note)
                .HasColumnType("text")
                .HasColumnName("note");
            entity.Property(e => e.Price).HasColumnName("price");
            entity.Property(e => e.ProductName)
                .HasMaxLength(45)
                .HasColumnName("product_name");
        });

        modelBuilder.Entity<Shipper>(entity =>
        {
            entity.HasKey(e => e.IdShipper).HasName("PRIMARY");

            entity.ToTable("shipper");

            entity.Property(e => e.IdShipper).HasColumnName("id_shipper");
            entity.Property(e => e.BienXo)
                .HasMaxLength(45)
                .HasColumnName("bien_xo");
            entity.Property(e => e.NameS)
                .HasColumnType("text")
                .HasColumnName("name_s");
            entity.Property(e => e.NumberPhone)
                .HasMaxLength(45)
                .HasColumnName("number_phone");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PRIMARY");

            entity
                .ToTable("user")
                .HasCharSet("utf8mb3")
                .UseCollation("utf8mb3_bin");

            entity.Property(e => e.Id).HasColumnName("id_user");
            entity.Property(e => e.Access)
                .HasMaxLength(45)
                .HasDefaultValueSql("'user'")
                .HasColumnName("access");
            entity.Property(e => e.Address)
                .HasMaxLength(1500)
                .HasDefaultValueSql("'UTH'")
                .HasColumnName("address");
            entity.Property(e => e.Age).HasColumnName("age");
            entity.Property(e => e.Email)
                .HasColumnType("text")
                .HasColumnName("email");
            entity.Property(e => e.Name)
                .HasColumnType("text")
                .HasColumnName("name");
            entity.Property(e => e.Password)
                .HasMaxLength(45)
                .HasColumnName("password");
            entity.Property(e => e.PhoneNumber)
                .HasMaxLength(45)
                .HasColumnName("phone_number");
            entity.Property(e => e.UserName)
                .HasMaxLength(45)
                .HasColumnName("user_name");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
