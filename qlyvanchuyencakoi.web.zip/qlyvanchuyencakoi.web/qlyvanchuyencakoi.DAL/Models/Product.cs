﻿using System;
using System.Collections.Generic;

namespace qlyvanchuyencakoi.DAL.Models;

public partial class Product
{
    public int IdProduct { get; set; }

    public string ProductName { get; set; } = null!;

    public string Image { get; set; } = null!;

    public decimal Price { get; set; }

    public string? Note { get; set; }
}

