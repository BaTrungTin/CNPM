﻿using System;
using System.Collections.Generic;

namespace qlyvanchuyencakoi.DAL.Models;

public partial class InfoProduct
{
    public int IdInfoProduct { get; set; }

    public int ProducId { get; set; }

    public int IdUser1 { get; set; }

    public string ShippingMethod { get; set; } = null!;

    public string AllPrice { get; set; } = null!;

    public string PaymentMethod { get; set; } = null!;

    public string StatusShipping { get; set; } = null!;
}
