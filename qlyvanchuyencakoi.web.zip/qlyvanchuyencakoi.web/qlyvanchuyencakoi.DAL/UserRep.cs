﻿using qlyvanchuyencakoi.DAL.Models;
using qlyvanchuyencakoi.Common.DAL;
using qlyvanchuyencakoi.Common.Rsp;
using Microsoft.EntityFrameworkCore;

namespace qlyvanchuyencakoi.DAL
{
	public class UserRep : GenericRep<VanchuyencakoiContext, User>
	{
		public UserRep()
		{
		}


		public override User Read(int id)
		{
			var res = All.FirstOrDefault(c => c.Id == id);
			return res;
		}

		//public override User Read(string name)
		//{
		//	var res = All.FirstOrDefault(c => c.UserName == name);
		//	return res;
		//}

		public User Update(User user)
		{
			var res = All.FirstOrDefault(c => c.Id == user.Id);
			if (res != null)
			{
				res.Name = user.Name;
				res.Age = user.Age;
				res.UserName = user.UserName;
				res.Password = user.Password;
				res.Email = user.Email;
				res.PhoneNumber = user.PhoneNumber;
				res.Address = user.Address;
				res.Access = user.Access;
				Context.SaveChanges();
			}
			return res;
		}

		public User Delete(int id)
		{
			var m = base.All.First(i => i.Id == id);
			Context.Users.Remove(m);
			Context.SaveChanges();
			return m;
		}

		public SingleRsp Create(User user)
		{
			var res = new SingleRsp();
			Context.Users.Add(user);
			Context.SaveChanges();
			res.Data = user;
			return res;
		}
	}
}