﻿
using qlyvanchuyencakoi.Common.DAL;
using qlyvanchuyencakoi.Common.Rsp;
using qlyvanchuyencakoi.DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace qlyvanchuyencakoi.DAL
{
	public class FeedBackRep : GenericRep<VanchuyencakoiContext, FeedBack>
	{
		public FeedBackRep() { }

		public override FeedBack Read(int id)
		{
			var res = All.FirstOrDefault(c => c.IdFeedBack == id);
			return res;
		}
		public SingleRsp Create(FeedBack feedBack)
		{
			var res = new SingleRsp();
			Context.FeedBacks.Add(feedBack);
			Context.SaveChanges();
			res.Data = feedBack;
			return res;
		}

		public FeedBack Update(FeedBack feedBack)
		{
			var res = All.FirstOrDefault(c => c.IdFeedBack == feedBack.IdFeedBack);
			if (res != null)
			{
				res.IdFeedBack = feedBack.IdFeedBack;
				res.IdProduct1 = feedBack.IdProduct1;
				res.FeedBackContent = feedBack.FeedBackContent;
				Context.SaveChanges();
			}
			return res;
		}

		public FeedBack Delete(int id)
		{
			var m = base.All.First(i => i.IdFeedBack == id);
			Context.FeedBacks.Remove(m);
			Context.SaveChanges();
			return m;
		}
	}
}
