﻿using qlyvanchuyencakoi.Common.DAL;
using qlyvanchuyencakoi.Common.Rsp;
using qlyvanchuyencakoi.DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace qlyvanchuyencakoi.DAL
{
	public class InfoProductRep : GenericRep<VanchuyencakoiContext, InfoProduct>
	{
		public InfoProductRep() { }

		public override InfoProduct Read(int id)
		{
			var res = All.FirstOrDefault(c => c.IdInfoProduct == id);
			return res;
		}
		public SingleRsp Create(InfoProduct infoproduct)
		{
			var res = new SingleRsp();
			Context.InfoProducts.Add(infoproduct);
			Context.SaveChanges();
			res.Data = infoproduct;
			return res;
		}

		public InfoProduct Update(InfoProduct infoproduct)
		{
			var res = All.FirstOrDefault(c => c.IdInfoProduct == infoproduct.IdInfoProduct);
			if (res != null)
			{			
				res.ProducId = infoproduct.ProducId;
				res.ShippingMethod = infoproduct.ShippingMethod;
				res.PaymentMethod = infoproduct.PaymentMethod;
				res.AllPrice = infoproduct.AllPrice;
				res.StatusShipping = infoproduct.StatusShipping;
				Context.SaveChanges();
			}
			return res;
		}

		public InfoProduct Delete(int id)
		{
			var m = base.All.First(i => i.IdInfoProduct == id);
			Context.InfoProducts.Remove(m);
			Context.SaveChanges();
			return m;
		}
	}
}
