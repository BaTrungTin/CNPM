﻿using qlyvanchuyencakoi.Common.DAL;
using qlyvanchuyencakoi.Common.Rsp;
using qlyvanchuyencakoi.DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace qlyvanchuyencakoi.DAL
{
	public class ProductRep : GenericRep<VanchuyencakoiContext, Product>
	{
		public ProductRep() { }

		public override Product Read(int id)
		{
			var res = All.FirstOrDefault(c => c.IdProduct == id);
			return res;
		}

		public SingleRsp Create(Product product)
		{
			var res = new SingleRsp();
			Context.Products.Add(product);
			Context.SaveChanges();
			res.Data = product;
			return res;
		}

		public Product Update(Product product)
		{
			var res = All.FirstOrDefault(c => c.IdProduct == product.IdProduct);
			if (res != null)
			{
				res.ProductName = product.ProductName;
				res.Price = product.Price;
				res.Image = product.Image;
				res.Note = product.Note;
				Context.SaveChanges();
			}
			return res;
		}

		public Product Delete(int id)
		{
			var m = base.All.First(i => i.IdProduct == id);
			Context.Products.Remove(m);
			Context.SaveChanges();
			return m;
		}

	}
}
