﻿using qlyvanchuyencakoi.Common.DAL;
using qlyvanchuyencakoi.Common.Rsp;
using qlyvanchuyencakoi.DAL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace qlyvanchuyencakoi.DAL
{
	public class ShipperRep : GenericRep<VanchuyencakoiContext, Shipper>
	{
		public ShipperRep() { }

		public override Shipper Read(int id)
		{
			var res = All.FirstOrDefault(c => c.IdShipper == id);
			return res;
		}

		public SingleRsp Create(Shipper shipper)
		{
			var res = new SingleRsp();
			Context.Shippers.Add(shipper);
			Context.SaveChanges();
			res.Data = shipper;
			return res;
		}

		public Shipper Update(Shipper shipper)
		{
			var res = All.FirstOrDefault(c => c.IdShipper == shipper.IdShipper);
			if (res != null)
			{
				res.NameS = shipper.NameS;
				res.NumberPhone = shipper.NumberPhone;
				res.BienXo = shipper.BienXo;
				Context.SaveChanges();
			}
			return res;
		}

		public Shipper Delete(int id)
		{
			var m = base.All.First(i => i.IdShipper == id);
			Context.Shippers.Remove(m);
			Context.SaveChanges();
			return m;
		}
	}
}
