﻿namespace qlyvanchuyencakoi.Common.Res
{
    public abstract class BaseReq<T>
    {
        #region --Methods--
        public BaseReq()
        {
            Name = string.Empty;
        }

        public BaseReq(int id)
        {
            Id = id;
        }

        public BaseReq(string name)
        {
            Name = name;
        }


        public abstract T ToModel(int? createBy = null);
        #endregion

        #region --Properties--
        public int Id { get; set; }
        public string Name { get; set; }
        #endregion
    }
}
