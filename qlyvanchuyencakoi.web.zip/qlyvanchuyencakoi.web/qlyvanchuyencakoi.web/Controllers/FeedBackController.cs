﻿using Microsoft.AspNetCore.Mvc;
using qlyvanchuyencakoi.BLL;
using qlyvanchuyencakoi.Common.Res;
using qlyvanchuyencakoi.Common.Rsp;
using qlyvanchuyencakoi.DAL.Models;

namespace qlyvanchuyencakoi.web.Controllers
{
	public class FeedBackController : Controller
	{
		private FeedBackSvc FeedBackSvc;
		public FeedBackController()
		{
			FeedBackSvc = new FeedBackSvc();

		}

		#region --get-by-id-feedback--
		[HttpPost("get-by-id-feedback")]
		public IActionResult GetFeedBackByID([FromQuery] SimpleReq simpleReq)
		{
			var res = new SingleRsp();
			res = FeedBackSvc.Read(simpleReq.Id);
			return Ok(res);
		}
		#endregion

		#region --update-feedback--
		[HttpPost("update-feedback")]
		public IActionResult UpdateFeedBack([FromBody] FeedBack feedback)
		{
			var res = new SingleRsp();

			// Kiểm tra dữ liệu đầu vào
			if (feedback == null || feedback.IdFeedBack <= 0 || string.IsNullOrWhiteSpace(feedback.IdProduct1))
			{
				res.SetError("EZ106", "Dữ liệu không hợp lệ.");
				return BadRequest(res);
			}

			// Gọi phương thức UpdateProduct từ service
			res = FeedBackSvc.Update(feedback);

			// Kiểm tra kết quả cập nhật
			if (!res.Success)
			{
				return BadRequest(res);  // Nếu có lỗi, trả về lỗi
			}

			return Ok(res);  // Nếu thành công, trả về kết quả thành công
		}
		#endregion

		#region --create-feedback--
		[HttpPost("create-feedback")]
		public IActionResult CreateFeedBack([FromBody] FeedBack newFeedBack)
		{
			var res = new SingleRsp();

			// Kiểm tra dữ liệu đầu vào
			if (newFeedBack == null || newFeedBack.IdFeedBack <= 0 || string.IsNullOrWhiteSpace(newFeedBack.IdProduct1))
			{
				res.SetError("EZ106", "Thông tin người dùng không hợp lệ.");
				return BadRequest(res);
			}

			// Tạo mới sản phẩm thông qua lớp service
			res = FeedBackSvc.Create(newFeedBack);

			// Trả về kết quả thành công hoặc thất bại dựa vào service
			if (!res.Success)
			{
				return BadRequest(res); // Trả về lỗi nếu quá trình tạo thất bại
			}

			return Ok(res); // Trả về thành công nếu tạo sản phẩm thành công
		}

		#endregion

		#region --delete-feedback--
		[HttpDelete("delete-feedback")]
		public IActionResult DeleteFeedBack([FromBody] int IdFeedBack)
		{
			var res = FeedBackSvc.Delete(IdFeedBack);

			if (!res.Success)
			{
				return BadRequest(res); // Trả về lỗi nếu quá trình xóa thất bại
			}

			return Ok(res);
		}
		#endregion
	}
}
