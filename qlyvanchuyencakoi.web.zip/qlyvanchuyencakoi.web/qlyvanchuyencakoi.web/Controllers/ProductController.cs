﻿using Microsoft.AspNetCore.Mvc;
using qlyvanchuyencakoi.BLL;
using qlyvanchuyencakoi.Common.Res;
using qlyvanchuyencakoi.Common.Rsp;
using qlyvanchuyencakoi.DAL.Models;

namespace qlyvanchuyencakoi.web.Controllers
{
	public class ProductController : Controller
	{
		private ProductSvc ProductSvc;
		public ProductController()
		{
			ProductSvc = new ProductSvc();

		}
		#region --get-by-id-product--
		[HttpPost("get-by-id-product")]
		public IActionResult GetUserByID([FromQuery] SimpleReq simpleReq)
		{
			var res = new SingleRsp();
			res = ProductSvc.Read(simpleReq.Id);
			return Ok(res);
		}
		#endregion

		#region --update-product--
		[HttpPost("update-product")]
		public IActionResult UpdateProduct([FromBody] Product product)
		{
			var res = new SingleRsp();

			// Kiểm tra dữ liệu đầu vào
			if (product == null || product.IdProduct <= 0)
			{
				res.SetError("EZ106", "Dữ liệu không hợp lệ.");
				return BadRequest(res);
			}

			// Gọi phương thức UpdateProduct từ service
			res = ProductSvc.Update(product);

			// Kiểm tra kết quả cập nhật
			if (!res.Success)
			{
				return BadRequest(res);  // Nếu có lỗi, trả về lỗi
			}

			return Ok(res);  // Nếu thành công, trả về kết quả thành công
		}
		#endregion

		#region --create-product--
		[HttpPost("create-product")]
		public IActionResult CreateProduct([FromBody] Product newProduct)
		{
			var res = new SingleRsp();

			// Kiểm tra dữ liệu đầu vào
			if (newProduct == null || string.IsNullOrWhiteSpace(newProduct.ProductName))
			{
				res.SetError("EZ106", "Thông tin người dùng không hợp lệ.");
				return BadRequest(res);
			}

			// Gọi phương thức tạo mới trong service
			res = ProductSvc.Create(newProduct);

			// Kiểm tra kết quả tạo mới
			if (!res.Success)
			{
				return BadRequest(res); // Trả về lỗi nếu quá trình tạo thất bại
			}

			return Ok(res); // Trả về thành công nếu tạo người dùng thành công
		}
		#endregion

		#region --delete-product--
		[HttpDelete("delete-product")]
		public IActionResult DeleteProduct([FromBody] int productId)
		{
			var res = ProductSvc.Delete(productId);

			if (!res.Success)
			{
				return BadRequest(res); // Trả về lỗi nếu quá trình xóa thất bại
			}

			return Ok(res);
		}
		#endregion

	}
}
