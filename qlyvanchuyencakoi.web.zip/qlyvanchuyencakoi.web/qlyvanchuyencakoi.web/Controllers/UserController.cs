﻿using Microsoft.AspNetCore.Mvc;
using qlyvanchuyencakoi.BLL;
using qlyvanchuyencakoi.Common.Res;
using qlyvanchuyencakoi.Common.Rsp;
using qlyvanchuyencakoi.DAL.Models;

namespace qlyvanchuyencakoi.web.Controllers
{
	public class UserController : Controller
	{
		private UserSvc userSvc;
		public UserController()
		{
			userSvc = new UserSvc();

		}
		#region --get-by-id-user--
		[HttpPost("get-by-id-user")]
		public IActionResult GetUserByID([FromQuery] SimpleReq simpleReq)
		{
			var res = new SingleRsp();
			res = userSvc.Read(simpleReq.Id);
			return Ok(res);
		}
		#endregion

		#region --get-by-name-user--
		//[HttpPost("get-by-name-user")]
		//public IActionResult GetUserByName([FromQuery] SimpleReq simpleReq)
		//{
		//	var res = new SingleRsp();
		//	res = userSvc.Read(simpleReq.Name);
		//	return Ok(res);
		//}
		#endregion

		#region --update-user--
		[HttpPost("update-user")]
		public IActionResult UpdateUser([FromBody] User user)
		{
			var res = new SingleRsp();

			// Kiểm tra dữ liệu đầu vào
			if (user == null || user.Id <= 0)
			{
				res.SetError("EZ106", "Dữ liệu không hợp lệ.");
				return BadRequest(res);
			}

			// Gọi phương thức UpdateUser từ service
			res = userSvc.Update(user);

			// Kiểm tra kết quả cập nhật
			if (!res.Success)
			{
				return BadRequest(res);  // Nếu có lỗi, trả về lỗi
			}

			return Ok(res);  // Nếu thành công, trả về kết quả thành công
		}
		#endregion

		#region --create-user--
		[HttpPost("create-user")]
		public IActionResult CreateUser([FromBody] User newUser)
		{
			var res = new SingleRsp();

			// Kiểm tra dữ liệu đầu vào
			if (newUser == null || string.IsNullOrWhiteSpace(newUser.Name) || string.IsNullOrWhiteSpace(newUser.Email))
			{
				res.SetError("EZ106", "Thông tin người dùng không hợp lệ.");
				return BadRequest(res);
			}

			// Gọi phương thức tạo mới trong service
			res = userSvc.Create(newUser);

			// Kiểm tra kết quả tạo mới
			if (!res.Success)
			{
				return BadRequest(res); // Trả về lỗi nếu quá trình tạo thất bại
			}

			return Ok(res); // Trả về thành công nếu tạo người dùng thành công
		}
		#endregion

		#region --delete-user--
		[HttpDelete("delete-user")]
		public IActionResult DeleteUser([FromBody] int userId)
		{
			var res = userSvc.Delete(userId);

			if (!res.Success)
			{
				return BadRequest(res); // Trả về lỗi nếu quá trình xóa thất bại
			}

			return Ok(res);
		}
		#endregion
	}
}