﻿using Microsoft.AspNetCore.Mvc;
using qlyvanchuyencakoi.BLL;
using qlyvanchuyencakoi.Common.Res;
using qlyvanchuyencakoi.Common.Rsp;
using qlyvanchuyencakoi.DAL.Models;

namespace qlyvanchuyencakoi.web.Controllers
{
	public class InfoProductController : Controller
	{
		private InfoProductSvc InfoProductSvc;
		public InfoProductController()
		{
			InfoProductSvc = new InfoProductSvc();

		}

		#region --get-by-id-infoproduct--
		[HttpPost("get-by-id-infoproduct")]
		public IActionResult GetInfoProductByID([FromQuery] SimpleReq simpleReq)
		{
			var res = new SingleRsp();
			res = InfoProductSvc.Read(simpleReq.Id);
			return Ok(res);
		}
		#endregion

		#region --update-infoproduct--
		[HttpPost("update-infoproduct")]
		public IActionResult UpdateProduct([FromBody] InfoProduct infoproduct)
		{
			var res = new SingleRsp();

			// Kiểm tra dữ liệu đầu vào
			if (infoproduct == null || infoproduct.IdInfoProduct <= 0)
			{
				res.SetError("EZ106", "Dữ liệu không hợp lệ.");
				return BadRequest(res);
			}

			// Gọi phương thức UpdateProduct từ service
			res = InfoProductSvc.Update(infoproduct);

			// Kiểm tra kết quả cập nhật
			if (!res.Success)
			{
				return BadRequest(res);  // Nếu có lỗi, trả về lỗi
			}

			return Ok(res);  // Nếu thành công, trả về kết quả thành công
		}
		#endregion

		#region --create-product--
		[HttpPost("create-infoproduct")]
		public IActionResult CreateInfoProduct([FromBody] InfoProduct newInfoProduct)
		{
			var res = new SingleRsp();

			// Kiểm tra dữ liệu đầu vào
			if (newInfoProduct == null || newInfoProduct.IdInfoProduct <= 0 || newInfoProduct.IdUser1 <= 0)
			{
				res.SetError("EZ106", "Thông tin người dùng không hợp lệ.");
				return BadRequest(res);
			}

			// Tạo mới sản phẩm thông qua lớp service
			res = InfoProductSvc.Create(newInfoProduct);

			// Trả về kết quả thành công hoặc thất bại dựa vào service
			if (!res.Success)
			{
				return BadRequest(res); // Trả về lỗi nếu quá trình tạo thất bại
			}

			return Ok(res); // Trả về thành công nếu tạo sản phẩm thành công
		}

		#endregion

		#region --delete-product--
		[HttpDelete("delete-infoproduct")]
		public IActionResult DeleteInfoProduct([FromBody] int IdInfoProduct)
		{
			var res = InfoProductSvc.Delete(IdInfoProduct);

			if (!res.Success)
			{
				return BadRequest(res); // Trả về lỗi nếu quá trình xóa thất bại
			}

			return Ok(res);
		}
		#endregion

	}
}
