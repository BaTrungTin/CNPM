﻿using Microsoft.AspNetCore.Mvc;
using qlyvanchuyencakoi.BLL;
using qlyvanchuyencakoi.Common.Res;
using qlyvanchuyencakoi.Common.Rsp;
using qlyvanchuyencakoi.DAL.Models;

namespace qlyvanchuyencakoi.web.Controllers
{
	public class ShipperController : Controller
	{
		private ShipperSvc ShipperSvc;
		public ShipperController()
		{
			ShipperSvc = new ShipperSvc();

		}
		#region --get-by-id-shipper--
		[HttpPost("get-by-id-shipper")]
		public IActionResult GetUserByID([FromQuery] SimpleReq simpleReq)
		{
			var res = new SingleRsp();
			res = ShipperSvc.Read(simpleReq.Id);
			return Ok(res);
		}
		#endregion

		#region --update-shipper--
		[HttpPost("update-shipper")]
		public IActionResult UpdateShipper([FromBody] Shipper shipper)
		{
			var res = new SingleRsp();

			// Kiểm tra dữ liệu đầu vào
			if (shipper == null || shipper.IdShipper <= 0)
			{
				res.SetError("EZ106", "Dữ liệu không hợp lệ.");
				return BadRequest(res);
			}

			// Gọi phương thức UpdateUser từ service
			res = ShipperSvc.Update(shipper);

			// Kiểm tra kết quả cập nhật
			if (!res.Success)
			{
				return BadRequest(res);  // Nếu có lỗi, trả về lỗi
			}

			return Ok(res);  // Nếu thành công, trả về kết quả thành công
		}
		#endregion

		#region --create-shipper--
		[HttpPost("create-shipper")]
		public IActionResult CreateShipper([FromBody] Shipper newShipper)
		{
			var res = new SingleRsp();

			// Kiểm tra dữ liệu đầu vào
			if (newShipper == null || string.IsNullOrWhiteSpace(newShipper.NameS) || string.IsNullOrWhiteSpace(newShipper.NumberPhone))
			{
				res.SetError("EZ106", "Thông tin người dùng không hợp lệ.");
				return BadRequest(res);
			}

			// Gọi phương thức tạo mới trong service
			res = ShipperSvc.Create(newShipper);

			// Kiểm tra kết quả tạo mới
			if (!res.Success)
			{
				return BadRequest(res); // Trả về lỗi nếu quá trình tạo thất bại
			}

			return Ok(res); // Trả về thành công nếu tạo người dùng thành công
		}
		#endregion

		#region --delete-shipper--
		[HttpDelete("delete-shipper")]
		public IActionResult DeleteShipper([FromBody] int shipperId)
		{
			var res = ShipperSvc.Delete(shipperId);

			if (!res.Success)
			{
				return BadRequest(res); // Trả về lỗi nếu quá trình xóa thất bại
			}

			return Ok(res);
		}
		#endregion

	}
}
